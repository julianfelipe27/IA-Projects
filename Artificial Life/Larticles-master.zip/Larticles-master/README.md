27/11/18 fixed some really really stupid bugs

15/09/18 fixed some really stupid bugs

# Larticles

Here will come the final version of Larticles / Living-Particles

# To run:

-clone/download, download as zip, unzip

-download python 3 (I made this in 3.5)

-python pip install pygame (in command line)

-and run GUI.py





# Commands:

left click = select particle/neuron

right click = unselect

scroll = zoom map

arrows = move map

end = return to original zoom and map position

qsdz = move map relative

r = restore relative position

k = kill particle

home = restart the big bang

insert = pause

f = calculate one frame

pagedown = toggle show more about the particles

pageup = toggle selected particle brain
